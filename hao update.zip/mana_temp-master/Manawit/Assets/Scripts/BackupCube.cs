﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackupCube : MonoBehaviour {
    public Globals.ElementType type;
    public int row;
    public int col;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

//    public void ChangeColor(){
//        switch (type)
//        {
//            case Globals.ElementType.Light:
//                this.GetComponent<Renderer>().material.color = Color.white;
//                break;
//            case Globals.ElementType.Fire:
//                this.GetComponent<Renderer>().material.color = Color.red;
//                break;
//            case Globals.ElementType.Water:
//                this.GetComponent<Renderer>().material.color = Color.blue;
//                break;
//            case Globals.ElementType.Wind:
//                this.GetComponent<Renderer>().material.color = Color.green;
//                break;
//            case Globals.ElementType.Earth:
//                this.GetComponent<Renderer>().material.color = Color.yellow;
//                break;
//            case Globals.ElementType.Dark:
//                this.GetComponent<Renderer>().material.color = Color.black;
//                break;
//        }
//
//    }
}
