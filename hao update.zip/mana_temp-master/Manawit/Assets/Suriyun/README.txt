﻿Animations Rig source = Avatar_for_Animation


Please note that character outline may look weird in scene view but will render correctly in game view
depend on shader setting - outline thickness  and the rendering camera setting - distance and field of view 
so adjusting these values will ensure the model look best on your setup.
----------------------------------------------

If you found any problem, please contact us.
Mail : contact@suriyun.com
Site : www.suriyun.com

----------------------------------------------
Shader by Unitychan! 
Download last version of shader http://unity-chan.com/

